## Readme

The Python implementation for the MLP and the CNN come as an attachment to this work.

* COMP_551_MLP_Image_Classification.ipynb — MLP code
* comp_551_mlp_image_classification.py — the same code for MLP but not as a Jupyter notebook, serves as an alternative to the Jupyter Notebook (but  Jupyter  Notebook  has  higher  interactivity and thus recommended for use
* MiniProject3_2_Keras.ipynb — CNN code